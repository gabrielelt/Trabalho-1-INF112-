#include <iostream>
#include "Matriz.h"

Matriz::Matriz(int dimensao)
{
    this->dimensao = dimensao;

    /* Alocação dos vetores (linhas) da matriz */
    for (int i = 0; i < dimensao; i++)
    { 
        this->endereco = new int* [dimensao];    
    }
   
    /* Alocação dos endereços de cada elemento da matriz(coluna)*/
    for (int i = 0; i < dimensao; i++)
    {
        this->endereco[i] = new int[dimensao];
    }   
}

void Matriz::leMatriz()
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            std::cout << "Digite o valor do elemento " << "a" << i+1 << j+1 << std::endl; 
            std::cin >> this->endereco[i][j];         
        }
    }
}

void Matriz::soma( Matriz Matriz2, Matriz Matriz3)
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            Matriz3.endereco[i][j] = this->endereco[i][j] + Matriz2.endereco[i][j];
        }
    }    
}

void Matriz::subtrai(Matriz Matriz2, Matriz Matriz3)
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            Matriz3.endereco[i][j] = this->endereco[i][j] - Matriz2.endereco[i][j] ;
        }
    }    
}

void Matriz::produto (Matriz Matriz2, Matriz Matriz3)
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            Matriz3.endereco[i][j] = 0;
        }
    }    

    for (int k = 0; k < dimensao; k++)
    {
        for (int i = 0; i < dimensao; i++)
        {
            for (int j = 0; j < dimensao; j++)
            {
                Matriz3.endereco[k][i] += this->endereco[k][j]*Matriz2.endereco[j][i];
            }
        }
    }    
}

void Matriz::criaMatrizIdentidade()
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            if (i ==j) 
            {
                this->endereco[i][j] = 1;
            }else{
                this->endereco[i][j] = 0;    
            }         
        }
    }
}

void Matriz::criaTransposta(Matriz MatrizT)
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            if (i > j) 
            {
                //int aux = this->endereco[i][j];
                MatrizT.endereco[i][j] = this->endereco[j][i];
                MatrizT.endereco[j][i] = this->endereco[i][j];
            }
            else if (j == i)
            {
                MatrizT.endereco[i][j] = this->endereco[i][j];

            }
        }
    }
}
bool Matriz::compara(Matriz Matriz2)
{
    for (int i = 0; i < dimensao; i++)
        {
            for (int j = 0; j < dimensao; j++)
            {
                if(this->endereco[i][j] != Matriz2.endereco[i][j])
                {
                    return false;
                }    
            }
        }
    return true;
}

void Matriz::imprimeMatriz()
{
    for (int i = 0; i < dimensao; i++)
    {
        for (int j = 0; j < dimensao; j++)
        {
            std::cout << endereco[i][j] << " ";
        }
        std::cout << std::endl;
    }

    std::cout << std::endl;
}

Matriz::~Matriz()
{

}