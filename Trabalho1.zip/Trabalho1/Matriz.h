struct Matriz{    
    int dimensao;
    int** endereco;

    Matriz(int n);
    ~Matriz();
    void leMatriz();
    void soma(Matriz Matriz2, Matriz Matriz3);
    void subtrai(Matriz Matriz2, Matriz Matriz3);
    void produto (Matriz Matriz2, Matriz Matriz3);
    void criaMatrizIdentidade();
    void criaTransposta(Matriz MatrizT);
    bool compara(Matriz Matriz2);
    void imprimeMatriz();
};
