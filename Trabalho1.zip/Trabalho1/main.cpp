#include<iostream>
#include "Matriz.h"

int main()
{
    bool identidade;
    int n;
    std::cout << "Digite o tamanho da matriz quadrada (quantidade de linhas e colunas)" << std::endl;
    std::cin >> n;
    Matriz M1(n), M2(n), M3(n), R(n), I(n), T(n);
    M1.leMatriz();
    std::cout << "Matriz lida com sucesso!!!" << std::endl;
    M1.imprimeMatriz();
    std::cout << "Deseja multiplicar a matriz lida pela identidade correspondente?\n (Sim = 1 ou Nao = 0): " << std::endl;
    std::cin >> identidade;
    if(identidade)
    {
        I.criaMatrizIdentidade();
        M1.produto(I, R); 
    }else
    {
        std::cout << "Então, forneça os valores da matriz que deseja multiplicar:" << std::endl;
        M2.leMatriz();
        M1.produto(M2, R);
       
    }
    std::cout << "Matriz multiplicada com sucesso, aqui está seu resultado: \n\n";
    R.imprimeMatriz();

    std::cout << "Agora vamos comparar se as matrizes multiplicadas são as mesmas: \n";
    if (M1.compara(M2))
    {
        std::cout << "As matrizes sao iguais!!!" << std::endl;
    }
    else
    { 
        std::cout << "As matrizes sao diferentes!!!" << std::endl;
    }
    
    std::cout << "Agora criamos a matriz transposta do resultado \n";
    R.criaTransposta (T );
    T.imprimeMatriz();
    if (identidade) M2.leMatriz();
    std::cout << "Agora faremos a subtração das matrizes passadas: \n";   
    R.subtrai (M2 , M3 ); 
    std::cout << "Aqui está o resultado dessa diferença: \n";
    M3.imprimeMatriz ();
    std::cout << "A próxima operação será a de soma com as duas matrizes escolhidas: \n";
    R.soma (M2 , M3 ); 
    M3.imprimeMatriz ();
    
   return 0;
}